const express = require('express');
const router = express.Router();
const restaurantController = require('../controller/restaurants/restaurantController');
const verifyToken = require('../middlewares/verifyToken');

router.post('/create', verifyToken, restaurantController.create);
router.get('/list', verifyToken, restaurantController.list);
router.get('/:restaurantId', verifyToken, restaurantController.findById);
router.put('/update', verifyToken, restaurantController.update);
router.delete('/delete', verifyToken, restaurantController.delete);

module.exports = router;


