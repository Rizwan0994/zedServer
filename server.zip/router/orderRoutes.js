// routes/orderRoutes.js

const express = require('express');
const router = express.Router();
const orderController = require('../controller//orders/orderController');;
const verifyToken = require('../middlewares/verifyToken');

router.post('/place', verifyToken,orderController.placeOrder);//for users
router.get('/my-orders/:userId',verifyToken, orderController.getAllMyOrders);  //for users
router.get('/restaurant-orders/:restaurantId',verifyToken, orderController.getAllRestaurantOrders);//for restaurant
router.get('/details/:orderId',verifyToken, orderController.getOrderDetails); //for users
router.get('/active/:userId',verifyToken, orderController.getActiveOrder); //for restaurant

module.exports = router;